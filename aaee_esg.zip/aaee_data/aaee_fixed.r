library(readxl)
library(dplyr)
library(tidyr)
library(zoo)
library(knitr)
library(openxlsx)

# Function to calculate stock days
calculate_stock_days <- function(start_date, end_date, benchmark_data) {
  stock_days <- benchmark_data %>%
    filter(date >= start_date & date <= end_date) %>%
    nrow()
  return(stock_days)
}

# Function for Event Study
perform_event_study <- function(industry_data, benchmark_data, event_date, event_window_size = 5, estimation_window_size = 100) {
  # Filter data for the estimation window
  estimation_window_start <- max((event_date - estimation_window_size), min(benchmark_data$date))
  estimation_window_end <- event_date - 1  # One day before the event date
  
  estimation_stock_days <- calculate_stock_days(estimation_window_start, estimation_window_end, benchmark_data)
  
  estimation_window <- industry_data %>%
    filter(date > (event_date - estimation_stock_days) & date < event_date)
  
  # Calculate mean log return during the estimation window
  mean_return_estimation <- mean(estimation_window$log_ret)
  
  # Calculate stock days for event window
  event_window_start <- max((event_date - event_window_size), min(benchmark_data$date))
  event_window_end <- min((event_date + event_window_size), max(benchmark_data$date))
  
  event_stock_days <- calculate_stock_days(event_window_start, event_window_end, benchmark_data)
  
  # Filter data for the event window
  event_window <- industry_data %>%
    filter(date >= event_window_start & date <= event_window_end)
  
  # Calculate abnormal returns (AR) for the event window
  event_window <- event_window %>%
    mutate(ar = log_ret - mean_return_estimation)
  
  # Calculate cumulative abnormal returns (CAR)
  event_window <- event_window %>%
    mutate(car = cumsum(ar))
  
  # Join with the benchmark data for market-adjusted returns
  event_window <- event_window %>%
    left_join(benchmark_data, by = "date") %>%
    mutate(market_return = stoxx_log_ret) %>%
    mutate(ar_market_adj = ar - market_return,
           car_market_adj = cumsum(ar_market_adj))
  
  return(event_window)
}

# Updated T-test function for AR and CAR
perform_t_test <- function(event_study_result) {
  # Function to check if there is enough variability in the data
  enough_variability <- function(data) {
    length(unique(data)) > 1
  }
  
  # T-test for AR
  ar_t_test <- if (enough_variability(event_study_result$ar)) t.test(event_study_result$ar, mu = 0)$p.value else NA
  
  # T-test for CAR
  car_t_test <- if (enough_variability(event_study_result$car)) t.test(event_study_result$car, mu = 0)$p.value else NA
  
  # T-test for market-adjusted AR
  ar_market_adj_t_test <- if (enough_variability(event_study_result$ar_market_adj)) t.test(event_study_result$ar_market_adj, mu = 0)$p.value else NA
  
  # T-test for market-adjusted CAR
  car_market_adj_t_test <- if (enough_variability(event_study_result$car_market_adj)) t.test(event_study_result$car_market_adj, mu = 0)$p.value else NA
  
  return(c(ar = ar_t_test, car = car_t_test, ar_market_adj = ar_market_adj_t_test, car_market_adj = car_market_adj_t_test))
}

# Read the benchmark data
stoxx600 <- read_excel("stoxx_600.xls")

# Process the benchmark data
benchmark <- stoxx600 %>%
  slice(8:nrow(stoxx600)) %>%
  rename(date = 1, price = 2, volume = 3) %>% 
  mutate(price = as.numeric(price)) %>% 
  mutate(date = as.numeric(date)) %>% 
  mutate(date = as.Date(date, origin = "1899-12-30")) %>% 
  arrange(date) %>% 
  select(1, 2) %>% 
  drop_na() %>% 
  mutate(lag_price = lag(price)) %>% 
  mutate(log_ret = log(price / lag_price)) %>% 
  select(date, log_ret) %>% 
  rename(stoxx_log_ret = log_ret)

# Get a list of all .xlsx files in the directory
excel_files <- list.files(pattern = "\\.xlsx$")

# Create an empty list to store the processed data frames
processed_data_list <- list()

# Define a function that processes a data frame
process_data <- function(auto_parts) {
  auto_parts_edited <- as_tibble(auto_parts) %>%
    slice(8:nrow(auto_parts)) %>%
    rename(date = 1, price = 2, volume = 3) %>% 
    mutate(price = as.numeric(price)) %>% 
    mutate(date = as.numeric(date)) %>% 
    mutate(date = as.Date(date, origin = "1899-12-30")) %>% 
    arrange(date) %>% 
    select(1, 2) %>% 
    drop_na() %>% 
    mutate(lag_price = lag(price)) %>% 
    mutate(log_ret = log(price / lag_price)) %>% 
    mutate(NFRD_biz = 0, NFRD_parl = 0, NFRD_hat = 0, CSRD_biz = 0, CSRD_parl = 0, CSRD_hat = 0) %>% 
    mutate(NFRD_biz = ifelse(date == "2013-04-16", 1, NFRD_biz),
           NFRD_parl = ifelse(date == "2014-04-15", 1, NFRD_parl),
           NFRD_hat = ifelse(date == "2017-12-06", 1, NFRD_hat),
           CSRD_biz = ifelse(date == "2021-04-21", 1, CSRD_biz),
           CSRD_parl = ifelse(date == "2022-11-10", 1, CSRD_parl),
           CSRD_hat = ifelse(date == "2023-01-02", 1, CSRD_hat))
  
  return(auto_parts_edited)
}

# Iterate through each Excel file, read and process it, and store the processed data frame in a named list
for (file in excel_files) {
  auto_parts <- read_xlsx(file)  # Read the current Excel file
  processed_data <- process_data(auto_parts)  # Process the data
  processed_data_list[[file]] <- processed_data  # Store the processed data frame in the list
}

# Event Study Loop
event_study_results_list <- list()
t_test_results_list <- list()


# Iterate through each industry
for (file in names(processed_data_list)) {
  industry_data <- processed_data_list[[file]]
  
  for (event_date in c("2013-04-16", "2014-04-15", "2017-12-06", "2021-04-21", "2022-11-10", "2023-01-02")) {
    # Perform event study
    event_study_result <- perform_event_study(industry_data, benchmark, as.Date(event_date), 5, 100)
    
    # Perform t-test
    t_test_result <- perform_t_test(event_study_result)
    
    # Store the results in the lists
    event_study_results_list[[paste(file, event_date, sep = "_")]] <- event_study_result
    t_test_results_list[[paste(file, event_date, sep = "_")]] <- t_test_result
  }
}

# Create and print a table of t-test p-values
t_test_table <- matrix(nrow = length(t_test_results_list), ncol = 4)
colnames(t_test_table) <- c("AR", "CAR", "AR_market_adj", "CAR_market_adj")

i <- 1
for (key in names(t_test_results_list)) {
  t_test_table[i, ] <- sapply(t_test_results_list[[key]], function(x) x)
  i <- i + 1
}

rownames(t_test_table) <- names(t_test_results_list)


# Modify the table
modified_t_test_table <- as.data.frame(t_test_table)

modified_t_test_table <- modified_t_test_table %>% 
  tibble::rownames_to_column(var = "File_Name") %>% 
  mutate(Date = as.Date(sub('.*_(\\d{4}-\\d{2}-\\d{2})$', '\\1', File_Name))) %>% 
  mutate(Industry = case_when(
    startsWith(File_Name, "auto_parts") ~ "Automobiles and Parts",
    startsWith(File_Name, "banks") ~ "Banks",
    startsWith(File_Name, "basic") ~ "Basic Resources",
    startsWith(File_Name, "chemicals") ~ "Chemiclas",
    startsWith(File_Name, "cons_prod_serv") ~ "Consumer Products and Services",
    startsWith(File_Name, "consturct_mat") ~ "Construction and Materials",
    startsWith(File_Name, "energy") ~ "Energy",
    startsWith(File_Name, "esg.xlsx") ~ "Top ESG Scores",
    startsWith(File_Name, "fin_serv") ~ "Financial Services",
    startsWith(File_Name, "food_bev") ~ "Food, Beverage and Tobacco",
    startsWith(File_Name, "health_care") ~ "Health Care",
    startsWith(File_Name, "ind_goods_serv") ~ "Industrial Goods and Services",
    startsWith(File_Name, "insurance") ~ "Insurance",
    startsWith(File_Name, "low_carbon") ~ "Low Carbon",
    startsWith(File_Name, "media") ~ "Media",
    startsWith(File_Name, "pers_care_drug") ~ "Personal Care, Drug and Grocery Stores",
    startsWith(File_Name, "real_estate") ~ "Real Estate",
    startsWith(File_Name, "retail") ~ "Retail",
    startsWith(File_Name, "tech") ~ "Technology",
    startsWith(File_Name, "telecomm") ~ "Telecommunications",
    startsWith(File_Name, "trav_lei") ~ "Travel and Leisure",
    startsWith(File_Name, "utility") ~ "Utility",
    # Add more conditions as needed
    
    # If none of the conditions match, keep the original value
    TRUE ~ as.character(File_Name)
  )) %>%
  select(-File_Name) %>% # Drop the original "File_Name" column if you want
  select(Industry, Date, everything())

write.xlsx(modified_t_test_table, file = "output.xlsx")
